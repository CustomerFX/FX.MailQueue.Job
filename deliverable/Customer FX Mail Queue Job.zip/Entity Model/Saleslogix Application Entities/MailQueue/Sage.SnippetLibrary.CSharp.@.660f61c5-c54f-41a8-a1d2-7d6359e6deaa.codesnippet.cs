/*
 * This metadata is used by the Saleslogix platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="660f61c5-c54f-41a8-a1d2-7d6359e6deaa">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>MailQueueProcessedStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
    public static partial class MailQueueBusinessRules
    {
        public static void MailQueueProcessedStep(IMailQueue mailqueue)
        {
            /* 
			This business rule is executed after a MailQueue record has been 
			processed and the email has been sent. Use this to add any custom 
			logic you'd like to have happen after the e-mail has been sent. 
			Note: this is not executed if the e-mail send attempt resulted 
			in an error.
			*/
			
        }
    }
}